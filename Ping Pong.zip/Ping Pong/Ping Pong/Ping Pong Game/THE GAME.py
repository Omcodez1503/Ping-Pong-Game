import turtle
import winsound

# Screen setup
wn = turtle.Screen()
wn.title('Ping Pong Game by Om Bhatt')
wn.bgpic('image.gif')
wn.setup(width=800, height=600)
wn.tracer(0)

# High Score
try:
    with open('highscore.txt', 'r') as f:
        high_score = int(f.read())
except:
    high_score = 0

# Score
score_a = 0
score_b = 0

# Pen for writing text
pen = turtle.Turtle()
pen.speed(0)
pen.color("yellow")
pen.penup()
pen.hideturtle()

def display_instructions():
    '''Display the game instructions'''
    pen.clear()
    pen.goto(0, 150)  # Moved instructions text down
    lines = [
        "Welcome to Ping Pong Game!",
        "",
        "Instructions:",
        "Player A (Left): Use 'w' to move up and 's' to move down.",
        "Player B (Right): Use 'Up' arrow to move up and 'Down' arrow to move down.",
        "First player to reach 5 points wins.",
        "Press 's' to start the game.",
        "Press 'q' to quit."
    ]
    for line in lines:
        pen.write(line, align="center", font=("Monaco", 13, "normal"))
        y = pen.ycor()
        pen.sety(y - 30)  # Move down for next line

def start_game():
    '''Start the game loop'''
    pen.clear()
    # Remove menu key bindings
    wn.onkeypress(None, 's')
    wn.onkeypress(None, 'i')
    wn.onkeypress(None, 'q')
    setup_game()
    game_loop()

def quit_game():
    '''Quit the game'''
    wn.bye()

def setup_game():
    global paddle_a, paddle_b, ball, pen, score_a, score_b

    score_a = 0
    score_b = 0

    # Paddle A
    paddle_a = turtle.Turtle()
    paddle_a.speed(0)
    paddle_a.shape("square")
    paddle_a.color("white")
    paddle_a.shapesize(stretch_wid=5, stretch_len=1)
    paddle_a.penup()
    paddle_a.goto(-350, 0)

    # Paddle B
    paddle_b = turtle.Turtle()
    paddle_b.speed(0)
    paddle_b.shape("square")
    paddle_b.color("white")
    paddle_b.shapesize(stretch_wid=5, stretch_len=1)
    paddle_b.penup()
    paddle_b.goto(350, 0)

    # Ping Pong Ball
    ball = turtle.Turtle()
    ball.speed(0)
    ball.shape("square")
    ball.color("white")
    ball.penup()
    ball.goto(0, 0)
    ball.dx = 5.1
    ball.dy = -5.1

    # Pen
    pen.goto(0, 260)
    pen.write("Player A: 0  Player B: 0", align="center", font=("Monaco", 24, "normal"))

    # Keyboard Binding/Controls
    wn.listen()
    wn.onkeypress(paddle_a_up, "w")
    wn.onkeypress(paddle_a_down, "s")
    wn.onkeypress(paddle_b_up, "Up")
    wn.onkeypress(paddle_b_down, "Down")

def paddle_a_up():
    y = paddle_a.ycor()
    y += 20
    if y > 250:
        y = 250
    paddle_a.sety(y)

def paddle_a_down():
    y = paddle_a.ycor()
    y -= 20
    if y < -250:
        y = -250
    paddle_a.sety(y)

def paddle_b_up():
    y = paddle_b.ycor()
    y += 20
    if y > 250:
        y = 250
    paddle_b.sety(y)

def paddle_b_down():
    y = paddle_b.ycor()
    y -= 20
    if y < -250:
        y = -250
    paddle_b.sety(y)

def game_loop():
    global score_a, score_b, high_score

    wn.update()

    # Move The Ball
    ball.setx(ball.xcor() + ball.dx)
    ball.sety(ball.ycor() + ball.dy)

    # Border Checking
    if ball.ycor() > 290:
        ball.sety(290)
        ball.dy *= -1
        winsound.PlaySound("wallhit_sound.wav", winsound.SND_ASYNC)

    elif ball.ycor() < -290:
        ball.sety(-290)
        ball.dy *= -1
        winsound.PlaySound("wallhit_sound.wav", winsound.SND_ASYNC)

    # Scoring
    if ball.xcor() > 390:
        ball.goto(0,0)
        ball.dx *= -1
        score_a += 1
        pen.clear()
        pen.goto(0, 260)
        pen.write("Player A: {}  Player B: {}".format(score_a, score_b), align="center", font=("Monaco", 24, "normal"))
        winsound.PlaySound("wallhit_sound.wav", winsound.SND_ASYNC)

    elif ball.xcor() < -390:
        ball.goto(0,0)
        ball.dx *= -1
        score_b += 1
        pen.clear()
        pen.goto(0, 260)
        pen.write("Player A: {}  Player B: {}".format(score_a, score_b), align="center", font=("Monaco", 24, "normal"))
        winsound.PlaySound("wallhit_sound.wav", winsound.SND_ASYNC)

    # Paddle Ball Collisions
    if (340 < ball.xcor() < 350) and (paddle_b.ycor() - 50 < ball.ycor() < paddle_b.ycor() + 50):
        ball.setx(340)
        ball.dx *= -1
        winsound.PlaySound("paddle_sound.wav", winsound.SND_ASYNC)

    elif (-350 < ball.xcor() < -340) and (paddle_a.ycor() - 50 < ball.ycor() < paddle_a.ycor() + 50):
        ball.setx(-340)
        ball.dx *= -1
        winsound.PlaySound("paddle_sound.wav", winsound.SND_ASYNC)

    # Check for winner
    if score_a >= 5 or score_b >=5:
        winner = "Player A" if score_a > score_b else "Player B"
        pen.clear()
        pen.goto(0,0)
        pen.write("{} Wins!".format(winner), align="center", font=("Monaco", 36, "normal"))
        if max(score_a, score_b) > high_score:
            high_score = max(score_a, score_b)
            with open('highscore.txt', 'w') as f:
                f.write(str(high_score))
        game_over()
        return  # Exit game loop

    # Schedule the next game loop
    wn.ontimer(game_loop, 20)

def game_over():
    '''Handle end of game, return to menu'''
    # Wait for a moment before returning to menu
    wn.ontimer(cleanup_and_display_menu, 2000)  # Wait 2 seconds

def cleanup_and_display_menu():
    '''Clean up game objects and display the menu'''
    # Hide and clear game objects
    paddle_a.hideturtle()
    paddle_b.hideturtle()
    ball.hideturtle()
    paddle_a.clear()
    paddle_b.clear()
    ball.clear()

    # Remove game key bindings
    wn.onkeypress(None, "w")
    wn.onkeypress(None, "s")
    wn.onkeypress(None, "Up")
    wn.onkeypress(None, "Down")

    # Display instructions again
    display_instructions()

    # Set up menu key bindings again
    wn.onkeypress(start_game, 's')
    wn.onkeypress(display_instructions, 'i')
    wn.onkeypress(quit_game, 'q')

# Display instructions at the start
display_instructions()

# Key bindings for menu
wn.listen()
wn.onkeypress(start_game, 's')
wn.onkeypress(display_instructions, 'i')
wn.onkeypress(quit_game, 'q')

# Main loop
wn.mainloop()
